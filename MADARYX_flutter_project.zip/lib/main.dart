import 'package:flutter/material.dart';

void main() => runApp(const MadaryxApp());

class MadaryxApp extends StatelessWidget {
  const MadaryxApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MADARYX',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff38bdf8), brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xff08111f),
      useMaterial3: true,
    ),
    home: const DashboardScreen(),
  );
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('المؤسسات', Icons.apartment, 'إدارة المؤسسات ومساحاتها'),
      ('المستخدمون', Icons.people_alt_outlined, 'الحسابات والأدوار'),
      ('التخصيص', Icons.palette_outlined, 'الألوان والصفحات والقوالب'),
      ('الملفات', Icons.folder_outlined, 'الصور والمستندات'),
      ('الإشعارات', Icons.notifications_outlined, 'التنبيهات والنشاط'),
      ('الإعدادات', Icons.settings_outlined, 'إعدادات المنصة'),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('MADARYX'), actions: [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Center(child: Text('Every Institution. One Digital Space.', style: TextStyle(color: Colors.lightBlue.shade200, fontSize: 11))))
      ]),
      drawer: Drawer(child: ListView(children: [
        const DrawerHeader(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children:[Text('MADARYX',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),Text('Super Admin')])),
        for(final item in items) ListTile(leading: Icon(item.$2), title: Text(item.$1), onTap:()=>Navigator.pop(context)),
      ])),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors:[Color(0xff102943),Color(0xff17233c)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
          Text('مساحة إدارة MADARYX',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
          SizedBox(height:8), Text('إدارة المؤسسات والخدمات من مساحة واحدة.',style:TextStyle(color:Colors.white70)),
          SizedBox(height:18), Text('Every Institution. One Digital Space.',style:TextStyle(color:Color(0xff67d4ff)))
        ])),
        const SizedBox(height:18),
        const Text('نظرة عامة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        Wrap(spacing:12,runSpacing:12,children:[
          stat('المؤسسات','0',Icons.apartment),
          stat('المستخدمون','0',Icons.people),
          stat('طلبات الإدارة','0',Icons.assignment_outlined),
        ]),
        const SizedBox(height:24), const Text('إدارة المنصة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        for(final item in items) Card(color:const Color(0xff111d2d),child:ListTile(
          leading:CircleAvatar(backgroundColor:const Color(0xff163752),child:Icon(item.$2,color:Colors.lightBlue.shade200)),
          title:Text(item.$1),subtitle:Text(item.$3),trailing:const Icon(Icons.chevron_left),
          onTap:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('القسم ده لسه تحت التطوير.'))),
        )),
        const SizedBox(height:18),
        const Text('تنبيه: هذه واجهة أولية، وليست متصلة بعد بقاعدة بيانات أو نظام صلاحيات.',style:TextStyle(color:Colors.orangeAccent)),
      ]),
    ));
  }
}

Widget stat(String label,String value,IconData icon)=>SizedBox(width:155,child:Card(color:const Color(0xff111d2d),child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Colors.lightBlue),const SizedBox(height:12),Text(value,style:const TextStyle(fontSize:26,fontWeight:FontWeight.bold)),Text(label)]))));
