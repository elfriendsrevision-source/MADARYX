# MADARYX Flutter starter

Starter UI for MADARYX. Not yet connected to a database or authentication.

## Build
1. Install Flutter SDK and Android SDK.
2. In this folder run `flutter pub get`.
3. Run `flutter run` or `flutter build apk --release`.

This repository starter is designed to be built in a cloud build environment as well.
