# MADARYX

Flutter application starter for MADARYX — Every Institution. One Digital Space.

## Included now
- Branded Arabic-first app shell with Home, Institutions, Features and Account tabs.
- Login / sign-up UI placeholders.
- Dark navy, cyan and gold visual identity.
- Android APK GitHub Actions workflow.

## Important status
This is the clean application foundation and first UI build, not the finished production platform.
Authentication, database, tenant isolation, Super Admin authorization, file storage, notifications and live institution management are NOT connected yet. Do not use it with real institution data until backend security and access rules are implemented and tested.

## Build locally
```bash
flutter pub get
flutter run
flutter build apk --release
```

## GitHub Actions
Push this project to the repository's `main` branch. The workflow `.github/workflows/build-apk.yml` builds and uploads `MADARYX-APK` as an artifact.
