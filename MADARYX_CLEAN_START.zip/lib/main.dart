import 'package:flutter/material.dart';

const navy = Color(0xFF07152F);
const panel = Color(0xFF102342);
const cyan = Color(0xFF12C8E8);
const gold = Color(0xFFFFC247);
const muted = Color(0xFF9DB0C9);

void main() => runApp(const MadaryxApp());

class MadaryxApp extends StatelessWidget {
  const MadaryxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MADARYX',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: cyan, brightness: Brightness.dark,
          surface: panel, primary: cyan, secondary: gold,
        ),
        fontFamily: 'Roboto',
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [HomePage(), InstitutionsPage(), FeaturesPage(), AccountPage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy,
        titleSpacing: 18,
        title: const BrandLockup(),
        actions: [
          IconButton(
            tooltip: 'الإشعارات',
            onPressed: () => _notice(context, 'الإشعارات هتظهر هنا بعد ربط قاعدة البيانات.'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(child: IndexedStack(index: selected, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0A1B35),
        indicatorColor: cyan.withOpacity(.16),
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.apartment_outlined), selectedIcon: Icon(Icons.apartment), label: 'المؤسسات'),
          NavigationDestination(icon: Icon(Icons.widgets_outlined), selectedIcon: Icon(Icons.widgets), label: 'المميزات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class BrandLockup extends StatelessWidget {
  const BrandLockup({super.key});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(colors: [cyan, Color(0xFF1763D6)]),
      ),
      child: const Center(child: Text('M', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: navy))),
    ),
    const SizedBox(width: 10),
    const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('MADARYX', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 17)),
      Text('مداركس', style: TextStyle(color: muted, fontSize: 11, height: 1)),
    ]),
  ]);
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(
            begin: Alignment.topRight, end: Alignment.bottomLeft,
            colors: [Color(0xFF123B68), Color(0xFF0B2142), Color(0xFF09172E)],
          ),
          border: Border.all(color: cyan.withOpacity(.22)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: cyan.withOpacity(.12), borderRadius: BorderRadius.circular(30)),
            child: const Text('منصة المؤسسات الذكية', style: TextStyle(color: cyan, fontWeight: FontWeight.w700, fontSize: 12)),
          ),
          const SizedBox(height: 22),
          const Text('كل مؤسسة،\nمساحة رقمية واحدة.', textDirection: TextDirection.rtl,
            style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, height: 1.35)),
          const SizedBox(height: 12),
          const Text('MADARYX تجمع أدوات الإدارة والمحتوى والخدمات في مساحة رقمية منظمة لكل مؤسسة.',
            textDirection: TextDirection.rtl, style: TextStyle(color: Color(0xFFD1DDED), height: 1.7)),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: cyan, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: () => _notice(context, 'إنشاء الحساب هيتفعّل بعد توصيل خدمة المصادقة.'),
              child: const Text('ابدأ الآن', style: TextStyle(fontWeight: FontWeight.bold)),
            )),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withOpacity(.35)), padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: () => _notice(context, 'هنضيف تفاصيل المنصة في صفحة تعريفية كاملة.'),
              child: const Text('اعرف المزيد'),
            )),
          ]),
        ]),
      ),
      const SizedBox(height: 24),
      const SectionTitle(title: 'مساحة واحدة لإدارة مؤسستك', subtitle: 'أدوات أساسية في مكان واحد'),
      const SizedBox(height: 14),
      const Wrap(spacing: 10, runSpacing: 10, children: [
        StatTile(value: '01', label: 'مساحة مستقلة', icon: Icons.domain),
        StatTile(value: '∞', label: 'قابلية للتوسع', icon: Icons.all_inclusive),
        StatTile(value: '24/7', label: 'وصول رقمي', icon: Icons.public),
      ]),
      const SizedBox(height: 24),
      const SectionTitle(title: 'ابدأ من هنا', subtitle: 'اختار الجزء اللي محتاج تستكشفه'),
      const SizedBox(height: 12),
      ActionCard(icon: Icons.apartment_rounded, title: 'المؤسسات', desc: 'استكشف طريقة تنظيم مساحات المؤسسات.', onTap: () => _notice(context, 'قائمة المؤسسات هتظهر بعد ربط البيانات.')),
      ActionCard(icon: Icons.tune_rounded, title: 'التخصيص والإدارة', desc: 'إعداد الهوية والأقسام والصلاحيات.', onTap: () => _notice(context, 'أدوات التخصيص هتُفعّل في مرحلة لوحة الإدارة.')),
    ],
  );
}

class InstitutionsPage extends StatelessWidget {
  const InstitutionsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SectionTitle(title: 'المؤسسات', subtitle: 'كل مؤسسة ليها مساحة رقمية مستقلة'),
    const SizedBox(height: 18),
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
      child: const Column(children: [
        Icon(Icons.apartment_rounded, size: 46, color: cyan),
        SizedBox(height: 12),
        Text('مساحات المؤسسات هتظهر هنا', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        SizedBox(height: 8),
        Text('بعد إعداد قاعدة البيانات وتسجيل المؤسسات، هتقدر توصل لمساحة كل مؤسسة من هنا.',
          textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.6)),
      ]),
    ),
    const SizedBox(height: 18),
    FilledButton.icon(
      onPressed: () => _notice(context, 'إضافة مؤسسة هتحتاج حساب مدير وصلاحية معتمدة على الخادم.'),
      icon: const Icon(Icons.add), label: const Text('طلب إضافة مؤسسة'),
      style: FilledButton.styleFrom(backgroundColor: cyan, foregroundColor: navy, padding: const EdgeInsets.all(14)),
    ),
  ]);
}

class FeaturesPage extends StatelessWidget {
  const FeaturesPage({super.key});
  final items = const [
    (Icons.dashboard_customize, 'لوحة تحكم موحدة', 'إدارة الأدوات والإعدادات من مكان واحد.'),
    (Icons.admin_panel_settings, 'صلاحيات وأدوار', 'فصل صلاحيات مدير المنصة عن مسؤولي المؤسسات.'),
    (Icons.palette_outlined, 'تخصيص الهوية', 'تغيير الألوان والشعار والأقسام حسب الصلاحية.'),
    (Icons.folder_copy_outlined, 'مركز الملفات', 'تنظيم ملفات المؤسسة وشعاراتها ومستنداتها.'),
    (Icons.notifications_active_outlined, 'الإشعارات', 'تنبيهات الحساب والطلبات والنشاط.'),
    (Icons.insights_outlined, 'الإحصائيات', 'متابعة الاستخدام والمؤشرات الرئيسية.'),
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SectionTitle(title: 'مميزات MADARYX', subtitle: 'تصميم المنصة قابل للتوسع حسب احتياجات المؤسسات'),
    const SizedBox(height: 16),
    ...items.map((e) => ActionCard(icon: e.$1, title: e.$2, desc: e.$3, onTap: () => _notice(context, 'الميزة دي ضمن خريطة التطوير، ولسه مش متوصلة بخدمة فعلية.'))),
  ]);
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SectionTitle(title: 'حسابك', subtitle: 'سجّل الدخول للوصول للخدمات المحمية'),
    const SizedBox(height: 18),
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
      child: const Column(children: [
        CircleAvatar(radius: 34, backgroundColor: Color(0xFF173D64), child: Icon(Icons.person_outline, size: 35, color: cyan)),
        SizedBox(height: 12),
        Text('مرحبًا بك في MADARYX', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text('تصفح التطبيق متاح بدون حساب. تسجيل الدخول مطلوب للخدمات المحمية.',
          textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.6)),
      ]),
    ),
    const SizedBox(height: 16),
    FilledButton(onPressed: () => _showAuth(context, false), style: FilledButton.styleFrom(backgroundColor: cyan, foregroundColor: navy, padding: const EdgeInsets.all(15)), child: const Text('تسجيل الدخول')),
    const SizedBox(height: 10),
    OutlinedButton(onPressed: () => _showAuth(context, true), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, padding: const EdgeInsets.all(15)), child: const Text('إنشاء حساب')),
    const SizedBox(height: 18),
    const Text('ملاحظة: تسجيل الحساب وحده لا يمنح صلاحيات إدارة المنصة أو أي مؤسسة.', textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.6, fontSize: 12)),
  ]);
}

void _showAuth(BuildContext context, bool signup) {
  final email = TextEditingController();
  final password = TextEditingController();
  showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: panel, builder: (ctx) => Padding(
    padding: EdgeInsets.fromLTRB(22, 22, 22, MediaQuery.of(ctx).viewInsets.bottom + 24),
    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text(signup ? 'إنشاء حساب' : 'تسجيل الدخول', textAlign: TextAlign.right, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور', border: OutlineInputBorder())),
      const SizedBox(height: 16),
      FilledButton(onPressed: () { Navigator.pop(ctx); _notice(context, 'واجهة الحساب جاهزة مبدئيًا؛ يلزم ربط مزود مصادقة وقاعدة بيانات قبل تفعيل التسجيل.'); },
        child: Text(signup ? 'إنشاء الحساب' : 'دخول')),
    ]),
  ));
}

class SectionTitle extends StatelessWidget {
  final String title, subtitle;
  const SectionTitle({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
    Text(title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
    const SizedBox(height: 5),
    Text(subtitle, textDirection: TextDirection.rtl, style: const TextStyle(color: muted, fontSize: 13)),
  ]);
}

class StatTile extends StatelessWidget {
  final String value, label; final IconData icon;
  const StatTile({super.key, required this.value, required this.label, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(width: (MediaQuery.of(context).size.width - 56) / 3, child: Container(
    padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 7),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white10)),
    child: Column(children: [
      Icon(icon, color: cyan, size: 22), const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: gold)),
      const SizedBox(height: 4),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: muted)),
    ]),
  ));
}

class ActionCard extends StatelessWidget {
  final IconData icon; final String title, desc; final VoidCallback onTap;
  const ActionCard({super.key, required this.icon, required this.title, required this.desc, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    color: panel, elevation: 0, margin: const EdgeInsets.only(bottom: 10),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Colors.white10)),
    child: ListTile(
      onTap: onTap, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: cyan.withOpacity(.12), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: cyan)),
      title: Text(title, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(desc, textDirection: TextDirection.rtl, style: const TextStyle(color: muted, height: 1.4))),
      trailing: const Icon(Icons.chevron_left, color: muted),
    ),
  );
}

void _notice(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message, textDirection: TextDirection.rtl), behavior: SnackBarBehavior.floating));
}
